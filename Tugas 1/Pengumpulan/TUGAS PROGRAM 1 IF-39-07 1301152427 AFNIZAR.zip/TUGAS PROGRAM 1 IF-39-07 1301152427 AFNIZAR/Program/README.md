# Simulated Annealing
Finding minimum value using simulated annealing

## How to Run
1. First thing first, make sure to install `node.js` on your computer, simply download it [here](https://nodejs.org/en/)
2. After that, open your terminal, change directory to this project
3. Then, type `node index.js` to run the file.

## Modifying the Code
1. If you want to **edit the code**, download `npm` right [here](https://www.npmjs.com/) then type in the terminal `npm install`.
2. After some package manager already installed, type again the terminal `coffee -w -c *.coffee`.
3. Have fun Modifying the code! ✨

### Step by step this algorithm works
1. First, generate a random solution
2. Calculate its cost using some cost function you've defined
3. Generate a random neighboring solution
4. Calculate the new solution's cost
5. Compare them: If cost_new < cost_old: move to the new solution; If cost_new > cost_old: maybe move to the new solution
6. Repeat steps 3-5 above until an acceptable solution is found or you reach some maximum number of iterations.
